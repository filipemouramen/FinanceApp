namespace FinanceApp.Domain.Entities;

public class FormaPagamento
{
    public int Id { get; set; }
    public string Nome { get; set; } = string.Empty;
    public string Icone { get; set; } = string.Empty;

    // Navegação
    public virtual ICollection<Transacao> Transacoes { get; set; } = new List<Transacao>();
}
