namespace FinanceApp.Domain.Entities;

public class LancamentoMeta
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public Guid MetaEconomiaId { get; set; }
    public decimal Valor { get; set; }
    public string? Observacoes { get; set; }
    public DateTime CriadoEm { get; set; } = DateTime.UtcNow;

    // Navegação
    public virtual MetaEconomia MetaEconomia { get; set; } = null!;
}
