namespace FinanceApp.Domain.Entities;

public class Notificacao
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public Guid UsuarioId { get; set; }
    public string Titulo { get; set; } = string.Empty;
    public string Mensagem { get; set; } = string.Empty;
    public string Tipo { get; set; } = string.Empty;  // ALERTA_ORCAMENTO, META_ATINGIDA, RECORRENCIA_VENCENDO, DICA
    public bool Lida { get; set; }
    public Guid? EntidadeRelacionadaId { get; set; }
    public DateTime CriadoEm { get; set; } = DateTime.UtcNow;

    // Navegação
    public virtual Usuario Usuario { get; set; } = null!;
}
