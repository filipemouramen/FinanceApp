namespace FinanceApp.Domain.Enums;

public enum TipoTransacao
{
    DESPESA,
    RECEITA
}

public enum OrigemTransacao
{
    APP,
    WHATSAPP
}

public enum TipoConta
{
    CORRENTE,
    POUPANCA,
    CARTEIRA,
    INVESTIMENTO
}

public enum StatusFatura
{
    ABERTA,
    FECHADA,
    PAGA,
    PARCIAL
}

public enum FrequenciaRecorrencia
{
    DIARIO,
    SEMANAL,
    MENSAL,
    ANUAL
}

public enum FinalidadeCodigo
{
    CONFIRMAR_EMAIL,
    RESETAR_SENHA
}
