using FinanceApp.Application.DTOs.Auth;
using FinanceApp.Application.DTOs.Categorias;
using FinanceApp.Application.DTOs.CartoesCredito;
using FinanceApp.Application.DTOs.Contas;
using FinanceApp.Application.DTOs.Dashboard;
using FinanceApp.Application.DTOs.Metas;
using FinanceApp.Application.DTOs.Orcamentos;
using FinanceApp.Application.DTOs.Transacoes;

namespace FinanceApp.Application.Interfaces;

// ===== RESULTADO PADRAO =====
public class Resultado<T>
{
    public bool Sucesso { get; set; }
    public T? Dados { get; set; }
    public string? Mensagem { get; set; }
    public List<string> Erros { get; set; } = new();

    public static Resultado<T> Ok(T dados, string? mensagem = null)
        => new() { Sucesso = true, Dados = dados, Mensagem = mensagem };

    public static Resultado<T> Falha(string erro)
        => new() { Sucesso = false, Erros = new List<string> { erro } };

    public static Resultado<T> Falha(List<string> erros)
        => new() { Sucesso = false, Erros = erros };
}

// ===== AUTENTICACAO =====
public interface IAuthService
{
    Task<Resultado<AuthResponse>> RegistrarAsync(RegistroRequest request);
    Task<Resultado<AuthResponse>> LoginAsync(LoginRequest request);
    Task<Resultado<AuthResponse>> RefreshTokenAsync(RefreshTokenRequest request);
    Task<Resultado<bool>> AlterarSenhaAsync(Guid usuarioId, AlterarSenhaRequest request);
    Task<Resultado<bool>> SolicitarResetSenhaAsync(SolicitarResetSenhaRequest request);
    Task<Resultado<bool>> ResetarSenhaAsync(ResetarSenhaRequest request);
    Task<Resultado<bool>> RevogarTokenAsync(Guid usuarioId);
}

// ===== TRANSACOES =====
public interface ITransacaoService
{
    Task<Resultado<TransacaoResponse>> CriarAsync(Guid usuarioId, CriarTransacaoRequest request);
    Task<Resultado<TransacaoResponse>> AtualizarAsync(Guid usuarioId, Guid transacaoId, AtualizarTransacaoRequest request);
    Task<Resultado<bool>> ExcluirAsync(Guid usuarioId, Guid transacaoId);
    Task<Resultado<TransacaoResponse>> ObterPorIdAsync(Guid usuarioId, Guid transacaoId);
    Task<Resultado<ListaPaginada<TransacaoResponse>>> ListarAsync(Guid usuarioId, FiltroTransacaoRequest filtro);
}

// ===== CATEGORIAS =====
public interface ICategoriaService
{
    Task<Resultado<List<CategoriaResponse>>> ListarAsync(Guid usuarioId, string? tipo = null);
    Task<Resultado<CategoriaResponse>> CriarAsync(Guid usuarioId, CriarCategoriaRequest request);
    Task<Resultado<bool>> ExcluirAsync(Guid usuarioId, int categoriaId);
}

// ===== CONTAS =====
public interface IContaService
{
    Task<Resultado<List<ContaResponse>>> ListarAsync(Guid usuarioId);
    Task<Resultado<ContaResponse>> CriarAsync(Guid usuarioId, CriarContaRequest request);
    Task<Resultado<ContaResponse>> AtualizarAsync(Guid usuarioId, Guid contaId, AtualizarContaRequest request);
    Task<Resultado<bool>> ExcluirAsync(Guid usuarioId, Guid contaId);
    Task<Resultado<bool>> TransferirAsync(Guid usuarioId, TransferenciaRequest request);
}

// ===== CARTOES DE CREDITO =====
public interface ICartaoCreditoService
{
    Task<Resultado<List<CartaoCreditoResponse>>> ListarAsync(Guid usuarioId);
    Task<Resultado<CartaoCreditoResponse>> CriarAsync(Guid usuarioId, CriarCartaoCreditoRequest request);
    Task<Resultado<bool>> ExcluirAsync(Guid usuarioId, Guid cartaoId);
    Task<Resultado<FaturaCartaoResponse>> ObterFaturaAsync(Guid usuarioId, Guid cartaoId, int mes, int ano);
    Task<Resultado<bool>> PagarFaturaAsync(Guid usuarioId, Guid faturaId, PagarFaturaRequest request);
}

// ===== ORCAMENTOS =====
public interface IOrcamentoService
{
    Task<Resultado<List<OrcamentoResponse>>> ListarPorMesAsync(Guid usuarioId, int mes, int ano);
    Task<Resultado<OrcamentoResponse>> CriarAsync(Guid usuarioId, CriarOrcamentoRequest request);
    Task<Resultado<bool>> ExcluirAsync(Guid usuarioId, Guid orcamentoId);
}

// ===== METAS =====
public interface IMetaService
{
    Task<Resultado<List<MetaResponse>>> ListarAsync(Guid usuarioId);
    Task<Resultado<MetaResponse>> CriarAsync(Guid usuarioId, CriarMetaRequest request);
    Task<Resultado<MetaResponse>> AdicionarLancamentoAsync(Guid usuarioId, Guid metaId, LancamentoMetaRequest request);
    Task<Resultado<bool>> ExcluirAsync(Guid usuarioId, Guid metaId);
}

// ===== DASHBOARD =====
public interface IDashboardService
{
    Task<Resultado<DashboardResponse>> ObterAsync(Guid usuarioId, int mes, int ano);
}
