using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;
using FinanceApp.Application.DTOs.Auth;
using FinanceApp.Application.Interfaces;
using FinanceApp.Domain.Entities;
using FinanceApp.Infrastructure.Data;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;

namespace FinanceApp.Application.Services;

public class AuthService : IAuthService
{
    private readonly UserManager<Usuario> _userManager;
    private readonly FinanceDbContext _context;
    private readonly IConfiguration _config;

    public AuthService(UserManager<Usuario> userManager, FinanceDbContext context, IConfiguration config)
    {
        _userManager = userManager;
        _context = context;
        _config = config;
    }

    public async Task<Resultado<AuthResponse>> RegistrarAsync(RegistroRequest request)
    {
        if (request.Senha != request.ConfirmarSenha)
            return Resultado<AuthResponse>.Falha("As senhas não conferem.");

        var existente = await _userManager.FindByEmailAsync(request.Email);
        if (existente != null)
            return Resultado<AuthResponse>.Falha("Este e-mail já está cadastrado.");

        var usuario = new Usuario
        {
            UserName = request.Email,
            Email = request.Email,
            NomeCompleto = request.NomeCompleto,
            TelefoneWhatsApp = request.TelefoneWhatsApp,
            EmailConfirmed = true // Simplificado para v1
        };

        var resultado = await _userManager.CreateAsync(usuario, request.Senha);
        if (!resultado.Succeeded)
            return Resultado<AuthResponse>.Falha(resultado.Errors.Select(e => e.Description).ToList());

        // Criar configurações padrão do usuário
        _context.ConfiguracoesUsuario.Add(new ConfiguracaoUsuario { UsuarioId = usuario.Id });
        await _context.SaveChangesAsync();

        var authResponse = await GerarTokensAsync(usuario);
        return Resultado<AuthResponse>.Ok(authResponse, "Conta criada com sucesso!");
    }

    public async Task<Resultado<AuthResponse>> LoginAsync(LoginRequest request)
    {
        var usuario = await _userManager.FindByEmailAsync(request.Email);
        if (usuario == null || !usuario.Ativo)
            return Resultado<AuthResponse>.Falha("E-mail ou senha inválidos.");

        var senhaValida = await _userManager.CheckPasswordAsync(usuario, request.Senha);
        if (!senhaValida)
            return Resultado<AuthResponse>.Falha("E-mail ou senha inválidos.");

        var authResponse = await GerarTokensAsync(usuario);
        return Resultado<AuthResponse>.Ok(authResponse);
    }

    public async Task<Resultado<AuthResponse>> RefreshTokenAsync(RefreshTokenRequest request)
    {
        var principal = ObterPrincipalDoTokenExpirado(request.Token);
        if (principal == null)
            return Resultado<AuthResponse>.Falha("Token inválido.");

        var usuarioId = Guid.Parse(principal.FindFirst(ClaimTypes.NameIdentifier)!.Value);

        var refreshToken = await _context.TokensAtualizacao
            .FirstOrDefaultAsync(t => t.Token == request.RefreshToken && t.UsuarioId == usuarioId);

        if (refreshToken == null || !refreshToken.Ativo)
            return Resultado<AuthResponse>.Falha("Refresh token inválido ou expirado.");

        // Revogar token antigo
        refreshToken.RevogadoEm = DateTime.UtcNow;

        var usuario = await _userManager.FindByIdAsync(usuarioId.ToString());
        if (usuario == null || !usuario.Ativo)
            return Resultado<AuthResponse>.Falha("Usuário não encontrado.");

        var authResponse = await GerarTokensAsync(usuario);

        // Marcar o token antigo como substituído
        refreshToken.SubstituidoPor = authResponse.RefreshToken;
        await _context.SaveChangesAsync();

        return Resultado<AuthResponse>.Ok(authResponse);
    }

    public async Task<Resultado<bool>> AlterarSenhaAsync(Guid usuarioId, AlterarSenhaRequest request)
    {
        if (request.NovaSenha != request.ConfirmarNovaSenha)
            return Resultado<bool>.Falha("As senhas não conferem.");

        var usuario = await _userManager.FindByIdAsync(usuarioId.ToString());
        if (usuario == null)
            return Resultado<bool>.Falha("Usuário não encontrado.");

        var resultado = await _userManager.ChangePasswordAsync(usuario, request.SenhaAtual, request.NovaSenha);
        if (!resultado.Succeeded)
            return Resultado<bool>.Falha(resultado.Errors.Select(e => e.Description).ToList());

        return Resultado<bool>.Ok(true, "Senha alterada com sucesso!");
    }

    public async Task<Resultado<bool>> SolicitarResetSenhaAsync(SolicitarResetSenhaRequest request)
    {
        var usuario = await _userManager.FindByEmailAsync(request.Email);
        if (usuario == null)
            return Resultado<bool>.Ok(true, "Se o e-mail existir, um código será enviado."); // Não revelar se existe

        var codigo = new Random().Next(100000, 999999).ToString();
        _context.CodigosVerificacao.Add(new CodigoVerificacao
        {
            UsuarioId = usuario.Id,
            Codigo = codigo,
            Finalidade = Domain.Enums.FinalidadeCodigo.RESETAR_SENHA,
            ExpiraEm = DateTime.UtcNow.AddMinutes(15)
        });
        await _context.SaveChangesAsync();

        // TODO: Enviar código por e-mail (implementar serviço de e-mail)
        // Temporariamente, retornar o código na mensagem (REMOVER EM PRODUÇÃO)
        return Resultado<bool>.Ok(true, $"Código enviado. (DEV: {codigo})");
    }

    public async Task<Resultado<bool>> ResetarSenhaAsync(ResetarSenhaRequest request)
    {
        var usuario = await _userManager.FindByEmailAsync(request.Email);
        if (usuario == null)
            return Resultado<bool>.Falha("Dados inválidos.");

        var codigoVerificacao = await _context.CodigosVerificacao
            .Where(c => c.UsuarioId == usuario.Id
                     && c.Codigo == request.Codigo
                     && c.Finalidade == Domain.Enums.FinalidadeCodigo.RESETAR_SENHA
                     && c.UsadoEm == null
                     && c.ExpiraEm > DateTime.UtcNow)
            .OrderByDescending(c => c.CriadoEm)
            .FirstOrDefaultAsync();

        if (codigoVerificacao == null)
            return Resultado<bool>.Falha("Código inválido ou expirado.");

        var token = await _userManager.GeneratePasswordResetTokenAsync(usuario);
        var resultado = await _userManager.ResetPasswordAsync(usuario, token, request.NovaSenha);

        if (!resultado.Succeeded)
            return Resultado<bool>.Falha(resultado.Errors.Select(e => e.Description).ToList());

        codigoVerificacao.UsadoEm = DateTime.UtcNow;
        await _context.SaveChangesAsync();

        return Resultado<bool>.Ok(true, "Senha resetada com sucesso!");
    }

    public async Task<Resultado<bool>> RevogarTokenAsync(Guid usuarioId)
    {
        var tokens = await _context.TokensAtualizacao
            .Where(t => t.UsuarioId == usuarioId && t.RevogadoEm == null)
            .ToListAsync();

        foreach (var token in tokens)
            token.RevogadoEm = DateTime.UtcNow;

        await _context.SaveChangesAsync();
        return Resultado<bool>.Ok(true, "Todos os tokens foram revogados.");
    }

    // ===== MÉTODOS PRIVADOS =====

    private async Task<AuthResponse> GerarTokensAsync(Usuario usuario)
    {
        var claims = new List<Claim>
        {
            new(ClaimTypes.NameIdentifier, usuario.Id.ToString()),
            new(ClaimTypes.Email, usuario.Email!),
            new(ClaimTypes.Name, usuario.NomeCompleto),
            new(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString())
        };

        var roles = await _userManager.GetRolesAsync(usuario);
        claims.AddRange(roles.Select(r => new Claim(ClaimTypes.Role, r)));

        var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_config["Jwt:Secret"]!));
        var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);
        var expiracao = DateTime.UtcNow.AddMinutes(int.Parse(_config["Jwt:ExpiracaoMinutos"]!));

        var token = new JwtSecurityToken(
            issuer: _config["Jwt:Emissor"],
            audience: _config["Jwt:Audiencia"],
            claims: claims,
            expires: expiracao,
            signingCredentials: creds
        );

        var tokenString = new JwtSecurityTokenHandler().WriteToken(token);

        // Gerar refresh token
        var refreshToken = GerarRefreshToken();
        _context.TokensAtualizacao.Add(new TokenAtualizacao
        {
            UsuarioId = usuario.Id,
            Token = refreshToken,
            ExpiraEm = DateTime.UtcNow.AddDays(int.Parse(_config["Jwt:RefreshTokenDias"]!))
        });
        await _context.SaveChangesAsync();

        return new AuthResponse
        {
            Token = tokenString,
            RefreshToken = refreshToken,
            ExpiraEm = expiracao,
            Usuario = new UsuarioResponse
            {
                Id = usuario.Id,
                NomeCompleto = usuario.NomeCompleto,
                Email = usuario.Email!,
                TelefoneWhatsApp = usuario.TelefoneWhatsApp,
                FotoUrl = usuario.FotoUrl
            }
        };
    }

    private static string GerarRefreshToken()
    {
        var randomBytes = new byte[64];
        using var rng = RandomNumberGenerator.Create();
        rng.GetBytes(randomBytes);
        return Convert.ToBase64String(randomBytes);
    }

    private ClaimsPrincipal? ObterPrincipalDoTokenExpirado(string token)
    {
        var parametros = new TokenValidationParameters
        {
            ValidateIssuerSigningKey = true,
            IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_config["Jwt:Secret"]!)),
            ValidateIssuer = true,
            ValidIssuer = _config["Jwt:Emissor"],
            ValidateAudience = true,
            ValidAudience = _config["Jwt:Audiencia"],
            ValidateLifetime = false // Permite token expirado
        };

        try
        {
            var principal = new JwtSecurityTokenHandler().ValidateToken(token, parametros, out var securityToken);
            if (securityToken is not JwtSecurityToken jwtToken ||
                !jwtToken.Header.Alg.Equals(SecurityAlgorithms.HmacSha256, StringComparison.InvariantCultureIgnoreCase))
                return null;

            return principal;
        }
        catch
        {
            return null;
        }
    }
}
