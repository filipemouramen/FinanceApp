using FinanceApp.Application.DTOs.Transacoes;
using FinanceApp.Application.Interfaces;
using FinanceApp.Domain.Entities;
using FinanceApp.Domain.Enums;
using FinanceApp.Infrastructure.Data;
using Microsoft.EntityFrameworkCore;

namespace FinanceApp.Application.Services;

public class TransacaoService : ITransacaoService
{
    private readonly FinanceDbContext _context;

    public TransacaoService(FinanceDbContext context)
    {
        _context = context;
    }

    public async Task<Resultado<TransacaoResponse>> CriarAsync(Guid usuarioId, CriarTransacaoRequest request)
    {
        var tipo = Enum.Parse<TipoTransacao>(request.Tipo);

        // Se tem parcelas, criar parcelamento
        Parcelamento? parcelamento = null;
        if (request.TotalParcelas.HasValue && request.TotalParcelas.Value >= 2)
        {
            parcelamento = new Parcelamento
            {
                UsuarioId = usuarioId,
                CartaoCreditoId = request.CartaoCreditoId,
                CategoriaId = request.CategoriaId,
                Descricao = request.Descricao ?? "Parcelamento",
                ValorTotal = request.Valor,
                ValorParcela = Math.Round(request.Valor / request.TotalParcelas.Value, 2),
                TotalParcelas = request.TotalParcelas.Value,
                DataPrimeiraParcela = request.DataTransacao ?? DateOnly.FromDateTime(DateTime.UtcNow)
            };
            _context.Parcelamentos.Add(parcelamento);
            await _context.SaveChangesAsync();

            // Criar todas as parcelas como transações futuras
            var dataBase = parcelamento.DataPrimeiraParcela;
            for (int i = 1; i <= parcelamento.TotalParcelas; i++)
            {
                var dataParcela = dataBase.AddMonths(i - 1);
                var transacaoParcela = new Transacao
                {
                    UsuarioId = usuarioId,
                    CategoriaId = request.CategoriaId,
                    ContaId = request.ContaId,
                    FormaPagamentoId = request.FormaPagamentoId,
                    CartaoCreditoId = request.CartaoCreditoId,
                    Valor = parcelamento.ValorParcela,
                    Tipo = tipo,
                    Descricao = $"{request.Descricao} ({i}/{parcelamento.TotalParcelas})",
                    DataTransacao = dataParcela,
                    Origem = OrigemTransacao.APP,
                    ParcelamentoId = parcelamento.Id,
                    NumeroParcela = i,
                    TotalParcelas = parcelamento.TotalParcelas
                };

                // Vincular à fatura se for cartão de crédito
                if (request.CartaoCreditoId.HasValue)
                    await VincularFaturaAsync(transacaoParcela, request.CartaoCreditoId.Value);

                _context.Transacoes.Add(transacaoParcela);
            }
            await _context.SaveChangesAsync();

            // Atualizar saldo da conta (apenas primeira parcela impacta agora se não for crédito)
            if (request.ContaId.HasValue && !request.CartaoCreditoId.HasValue)
                await AtualizarSaldoContaAsync(request.ContaId.Value, parcelamento.ValorParcela, tipo);

            var primeiraParcela = await ObterTransacaoComIncludesAsync(usuarioId, parcelamento.Id);
            return Resultado<TransacaoResponse>.Ok(primeiraParcela!, "Parcelamento criado com sucesso!");
        }

        // Transação simples (sem parcela)
        var transacao = new Transacao
        {
            UsuarioId = usuarioId,
            CategoriaId = request.CategoriaId,
            ContaId = request.ContaId,
            FormaPagamentoId = request.FormaPagamentoId,
            CartaoCreditoId = request.CartaoCreditoId,
            Valor = request.Valor,
            Tipo = tipo,
            Descricao = request.Descricao,
            DataTransacao = request.DataTransacao ?? DateOnly.FromDateTime(DateTime.UtcNow),
            Origem = OrigemTransacao.APP,
            Observacoes = request.Observacoes
        };

        if (request.CartaoCreditoId.HasValue)
            await VincularFaturaAsync(transacao, request.CartaoCreditoId.Value);

        _context.Transacoes.Add(transacao);
        await _context.SaveChangesAsync();

        // Atualizar saldo da conta (se não for crédito)
        if (request.ContaId.HasValue && !request.CartaoCreditoId.HasValue)
            await AtualizarSaldoContaAsync(request.ContaId.Value, request.Valor, tipo);

        var response = await ObterTransacaoResponseAsync(transacao.Id);
        return Resultado<TransacaoResponse>.Ok(response!);
    }

    public async Task<Resultado<TransacaoResponse>> AtualizarAsync(Guid usuarioId, Guid transacaoId, AtualizarTransacaoRequest request)
    {
        var transacao = await _context.Transacoes
            .FirstOrDefaultAsync(t => t.Id == transacaoId && t.UsuarioId == usuarioId);

        if (transacao == null)
            return Resultado<TransacaoResponse>.Falha("Transação não encontrada.");

        var valorAntigo = transacao.Valor;
        var tipoAntigo = transacao.Tipo;

        if (request.CategoriaId.HasValue) transacao.CategoriaId = request.CategoriaId.Value;
        if (request.ContaId.HasValue) transacao.ContaId = request.ContaId;
        if (request.FormaPagamentoId.HasValue) transacao.FormaPagamentoId = request.FormaPagamentoId;
        if (request.Valor.HasValue) transacao.Valor = request.Valor.Value;
        if (request.Descricao != null) transacao.Descricao = request.Descricao;
        if (request.DataTransacao.HasValue) transacao.DataTransacao = request.DataTransacao.Value;
        if (request.Observacoes != null) transacao.Observacoes = request.Observacoes;
        transacao.AtualizadoEm = DateTime.UtcNow;

        await _context.SaveChangesAsync();

        // Recalcular saldo se valor mudou
        if (transacao.ContaId.HasValue && request.Valor.HasValue && request.Valor.Value != valorAntigo)
        {
            // Reverter valor antigo e aplicar novo
            await ReverterSaldoContaAsync(transacao.ContaId.Value, valorAntigo, tipoAntigo);
            await AtualizarSaldoContaAsync(transacao.ContaId.Value, transacao.Valor, transacao.Tipo);
        }

        var response = await ObterTransacaoResponseAsync(transacao.Id);
        return Resultado<TransacaoResponse>.Ok(response!);
    }

    public async Task<Resultado<bool>> ExcluirAsync(Guid usuarioId, Guid transacaoId)
    {
        var transacao = await _context.Transacoes
            .FirstOrDefaultAsync(t => t.Id == transacaoId && t.UsuarioId == usuarioId);

        if (transacao == null)
            return Resultado<bool>.Falha("Transação não encontrada.");

        // Reverter saldo
        if (transacao.ContaId.HasValue && transacao.CartaoCreditoId == null)
            await ReverterSaldoContaAsync(transacao.ContaId.Value, transacao.Valor, transacao.Tipo);

        _context.Transacoes.Remove(transacao);
        await _context.SaveChangesAsync();

        return Resultado<bool>.Ok(true, "Transação excluída com sucesso!");
    }

    public async Task<Resultado<TransacaoResponse>> ObterPorIdAsync(Guid usuarioId, Guid transacaoId)
    {
        var response = await ObterTransacaoResponseAsync(transacaoId);
        if (response == null)
            return Resultado<TransacaoResponse>.Falha("Transação não encontrada.");

        return Resultado<TransacaoResponse>.Ok(response);
    }

    public async Task<Resultado<ListaPaginada<TransacaoResponse>>> ListarAsync(Guid usuarioId, FiltroTransacaoRequest filtro)
    {
        var query = _context.Transacoes
            .Include(t => t.Categoria)
            .Include(t => t.Conta)
            .Include(t => t.FormaPagamento)
            .Include(t => t.CartaoCredito)
            .Where(t => t.UsuarioId == usuarioId)
            .AsQueryable();

        // Filtros
        if (filtro.DataInicio.HasValue)
            query = query.Where(t => t.DataTransacao >= filtro.DataInicio.Value);
        if (filtro.DataFim.HasValue)
            query = query.Where(t => t.DataTransacao <= filtro.DataFim.Value);
        if (!string.IsNullOrEmpty(filtro.Tipo))
            query = query.Where(t => t.Tipo == Enum.Parse<TipoTransacao>(filtro.Tipo));
        if (filtro.CategoriaId.HasValue)
            query = query.Where(t => t.CategoriaId == filtro.CategoriaId.Value);
        if (filtro.ContaId.HasValue)
            query = query.Where(t => t.ContaId == filtro.ContaId.Value);
        if (!string.IsNullOrEmpty(filtro.Origem))
            query = query.Where(t => t.Origem == Enum.Parse<OrigemTransacao>(filtro.Origem));

        var total = await query.CountAsync();

        var itens = await query
            .OrderByDescending(t => t.DataTransacao)
            .ThenByDescending(t => t.CriadoEm)
            .Skip((filtro.Pagina - 1) * filtro.ItensPorPagina)
            .Take(filtro.ItensPorPagina)
            .Select(t => new TransacaoResponse
            {
                Id = t.Id,
                CategoriaId = t.CategoriaId,
                NomeCategoria = t.Categoria.Nome,
                IconeCategoria = t.Categoria.Icone,
                CorCategoria = t.Categoria.Cor,
                ContaId = t.ContaId,
                NomeConta = t.Conta != null ? t.Conta.Nome : null,
                FormaPagamentoId = t.FormaPagamentoId,
                NomeFormaPagamento = t.FormaPagamento != null ? t.FormaPagamento.Nome : null,
                CartaoCreditoId = t.CartaoCreditoId,
                NomeCartaoCredito = t.CartaoCredito != null ? t.CartaoCredito.Nome : null,
                Valor = t.Valor,
                Tipo = t.Tipo.ToString(),
                Descricao = t.Descricao,
                DataTransacao = t.DataTransacao,
                Origem = t.Origem.ToString(),
                Observacoes = t.Observacoes,
                NumeroParcela = t.NumeroParcela,
                TotalParcelas = t.TotalParcelas,
                CriadoEm = t.CriadoEm
            })
            .ToListAsync();

        var resultado = new ListaPaginada<TransacaoResponse>
        {
            Itens = itens,
            TotalItens = total,
            Pagina = filtro.Pagina,
            ItensPorPagina = filtro.ItensPorPagina
        };

        return Resultado<ListaPaginada<TransacaoResponse>>.Ok(resultado);
    }

    // ===== MÉTODOS PRIVADOS =====

    private async Task AtualizarSaldoContaAsync(Guid contaId, decimal valor, TipoTransacao tipo)
    {
        var conta = await _context.Contas.FindAsync(contaId);
        if (conta == null) return;

        conta.SaldoAtual += tipo == TipoTransacao.RECEITA ? valor : -valor;
        conta.AtualizadoEm = DateTime.UtcNow;
        await _context.SaveChangesAsync();
    }

    private async Task ReverterSaldoContaAsync(Guid contaId, decimal valor, TipoTransacao tipo)
    {
        var conta = await _context.Contas.FindAsync(contaId);
        if (conta == null) return;

        conta.SaldoAtual += tipo == TipoTransacao.RECEITA ? -valor : valor;
        conta.AtualizadoEm = DateTime.UtcNow;
        await _context.SaveChangesAsync();
    }

    private async Task VincularFaturaAsync(Transacao transacao, Guid cartaoCreditoId)
    {
        var cartao = await _context.CartoesCredito.FindAsync(cartaoCreditoId);
        if (cartao == null) return;

        // Determinar em qual fatura a transação cai
        var dataTransacao = transacao.DataTransacao;
        int mesFatura, anoFatura;

        if (dataTransacao.Day > cartao.DiaFechamento)
        {
            // Cai na fatura do próximo mês
            var proximoMes = dataTransacao.AddMonths(1);
            mesFatura = proximoMes.Month;
            anoFatura = proximoMes.Year;
        }
        else
        {
            mesFatura = dataTransacao.Month;
            anoFatura = dataTransacao.Year;
        }

        // Buscar ou criar fatura
        var fatura = await _context.FaturasCartao
            .FirstOrDefaultAsync(f => f.CartaoCreditoId == cartaoCreditoId
                                   && f.MesReferencia == mesFatura
                                   && f.AnoReferencia == anoFatura);

        if (fatura == null)
        {
            fatura = new FaturaCartao
            {
                CartaoCreditoId = cartaoCreditoId,
                UsuarioId = transacao.UsuarioId,
                MesReferencia = mesFatura,
                AnoReferencia = anoFatura,
                DataFechamento = new DateOnly(anoFatura, mesFatura, cartao.DiaFechamento),
                DataVencimento = new DateOnly(anoFatura, mesFatura, cartao.DiaVencimento)
            };
            _context.FaturasCartao.Add(fatura);
            await _context.SaveChangesAsync();
        }

        transacao.FaturaCartaoId = fatura.Id;

        // Atualizar valor total da fatura
        fatura.ValorTotal += transacao.Valor;
        fatura.AtualizadoEm = DateTime.UtcNow;
    }

    private async Task<TransacaoResponse?> ObterTransacaoResponseAsync(Guid transacaoId)
    {
        return await _context.Transacoes
            .Include(t => t.Categoria)
            .Include(t => t.Conta)
            .Include(t => t.FormaPagamento)
            .Include(t => t.CartaoCredito)
            .Where(t => t.Id == transacaoId)
            .Select(t => new TransacaoResponse
            {
                Id = t.Id,
                CategoriaId = t.CategoriaId,
                NomeCategoria = t.Categoria.Nome,
                IconeCategoria = t.Categoria.Icone,
                CorCategoria = t.Categoria.Cor,
                ContaId = t.ContaId,
                NomeConta = t.Conta != null ? t.Conta.Nome : null,
                FormaPagamentoId = t.FormaPagamentoId,
                NomeFormaPagamento = t.FormaPagamento != null ? t.FormaPagamento.Nome : null,
                CartaoCreditoId = t.CartaoCreditoId,
                NomeCartaoCredito = t.CartaoCredito != null ? t.CartaoCredito.Nome : null,
                Valor = t.Valor,
                Tipo = t.Tipo.ToString(),
                Descricao = t.Descricao,
                DataTransacao = t.DataTransacao,
                Origem = t.Origem.ToString(),
                Observacoes = t.Observacoes,
                NumeroParcela = t.NumeroParcela,
                TotalParcelas = t.TotalParcelas,
                CriadoEm = t.CriadoEm
            })
            .FirstOrDefaultAsync();
    }

    private async Task<TransacaoResponse?> ObterTransacaoComIncludesAsync(Guid usuarioId, Guid parcelamentoId)
    {
        return await _context.Transacoes
            .Include(t => t.Categoria)
            .Where(t => t.UsuarioId == usuarioId && t.ParcelamentoId == parcelamentoId && t.NumeroParcela == 1)
            .Select(t => new TransacaoResponse
            {
                Id = t.Id,
                CategoriaId = t.CategoriaId,
                NomeCategoria = t.Categoria.Nome,
                IconeCategoria = t.Categoria.Icone,
                CorCategoria = t.Categoria.Cor,
                Valor = t.Valor,
                Tipo = t.Tipo.ToString(),
                Descricao = t.Descricao,
                DataTransacao = t.DataTransacao,
                Origem = t.Origem.ToString(),
                NumeroParcela = t.NumeroParcela,
                TotalParcelas = t.TotalParcelas,
                CriadoEm = t.CriadoEm
            })
            .FirstOrDefaultAsync();
    }
}
