using FinanceApp.Application.DTOs.Dashboard;
using FinanceApp.Application.Interfaces;
using FinanceApp.Domain.Enums;
using FinanceApp.Infrastructure.Data;
using Microsoft.EntityFrameworkCore;

namespace FinanceApp.Application.Services;

public class DashboardService : IDashboardService
{
    private readonly FinanceDbContext _context;

    public DashboardService(FinanceDbContext context)
    {
        _context = context;
    }

    public async Task<Resultado<DashboardResponse>> ObterAsync(Guid usuarioId, int mes, int ano)
    {
        var transacoesMes = _context.Transacoes
            .Where(t => t.UsuarioId == usuarioId
                     && t.DataTransacao.Month == mes
                     && t.DataTransacao.Year == ano);

        var totalReceitas = await transacoesMes
            .Where(t => t.Tipo == TipoTransacao.RECEITA)
            .SumAsync(t => (decimal?)t.Valor) ?? 0;

        var totalDespesas = await transacoesMes
            .Where(t => t.Tipo == TipoTransacao.DESPESA)
            .SumAsync(t => (decimal?)t.Valor) ?? 0;

        // Gastos por categoria
        var gastosPorCategoria = await transacoesMes
            .Where(t => t.Tipo == TipoTransacao.DESPESA)
            .GroupBy(t => new { t.CategoriaId, t.Categoria.Nome, t.Categoria.Icone, t.Categoria.Cor })
            .Select(g => new GastoPorCategoriaResponse
            {
                CategoriaId = g.Key.CategoriaId,
                NomeCategoria = g.Key.Nome,
                IconeCategoria = g.Key.Icone,
                CorCategoria = g.Key.Cor,
                ValorTotal = g.Sum(t => t.Valor),
                QuantidadeTransacoes = g.Count()
            })
            .OrderByDescending(g => g.ValorTotal)
            .ToListAsync();

        // Calcular percentual
        foreach (var gasto in gastosPorCategoria)
            gasto.Percentual = totalDespesas > 0 ? Math.Round(gasto.ValorTotal / totalDespesas * 100, 1) : 0;

        // Balanço dos últimos 6 meses
        var dataInicio = new DateOnly(ano, mes, 1).AddMonths(-5);
        var balancoMensal = await _context.Transacoes
            .Where(t => t.UsuarioId == usuarioId && t.DataTransacao >= dataInicio)
            .GroupBy(t => new { Ano = t.DataTransacao.Year, Mes = t.DataTransacao.Month })
            .Select(g => new BalancoMensalResponse
            {
                Ano = g.Key.Ano,
                Mes = g.Key.Mes,
                TotalReceitas = g.Where(t => t.Tipo == TipoTransacao.RECEITA).Sum(t => t.Valor),
                TotalDespesas = g.Where(t => t.Tipo == TipoTransacao.DESPESA).Sum(t => t.Valor),
                Saldo = g.Where(t => t.Tipo == TipoTransacao.RECEITA).Sum(t => t.Valor)
                       - g.Where(t => t.Tipo == TipoTransacao.DESPESA).Sum(t => t.Valor)
            })
            .OrderBy(b => b.Ano).ThenBy(b => b.Mes)
            .ToListAsync();

        // Últimas 10 transações
        var transacoesRecentes = await _context.Transacoes
            .Include(t => t.Categoria)
            .Where(t => t.UsuarioId == usuarioId)
            .OrderByDescending(t => t.DataTransacao)
            .ThenByDescending(t => t.CriadoEm)
            .Take(10)
            .Select(t => new TransacaoRecenteResponse
            {
                Id = t.Id,
                Descricao = t.Descricao,
                NomeCategoria = t.Categoria.Nome,
                IconeCategoria = t.Categoria.Icone,
                CorCategoria = t.Categoria.Cor,
                Valor = t.Valor,
                Tipo = t.Tipo.ToString(),
                DataTransacao = t.DataTransacao
            })
            .ToListAsync();

        // Orçamentos ativos do mês
        var orcamentos = await _context.Orcamentos
            .Include(o => o.Categoria)
            .Where(o => o.UsuarioId == usuarioId && o.Mes == mes && o.Ano == ano)
            .ToListAsync();

        var orcamentosResumo = new List<OrcamentoResumoResponse>();
        foreach (var orc in orcamentos)
        {
            var totalGasto = await transacoesMes
                .Where(t => t.CategoriaId == orc.CategoriaId && t.Tipo == TipoTransacao.DESPESA)
                .SumAsync(t => (decimal?)t.Valor) ?? 0;

            orcamentosResumo.Add(new OrcamentoResumoResponse
            {
                NomeCategoria = orc.Categoria.Nome,
                CorCategoria = orc.Categoria.Cor,
                ValorLimite = orc.ValorLimite,
                TotalGasto = totalGasto,
                PercentualUsado = orc.ValorLimite > 0 ? Math.Round(totalGasto / orc.ValorLimite * 100, 1) : 0
            });
        }

        var dashboard = new DashboardResponse
        {
            TotalReceitas = totalReceitas,
            TotalDespesas = totalDespesas,
            Saldo = totalReceitas - totalDespesas,
            GastosPorCategoria = gastosPorCategoria,
            BalancoMensal = balancoMensal,
            TransacoesRecentes = transacoesRecentes,
            OrcamentosAtivos = orcamentosResumo
        };

        return Resultado<DashboardResponse>.Ok(dashboard);
    }
}
