namespace FinanceApp.Application.DTOs.Contas;

public class CriarContaRequest
{
    public string Nome { get; set; } = string.Empty;
    public string TipoConta { get; set; } = "CORRENTE";
    public string? Banco { get; set; }
    public string Cor { get; set; } = "#6C63FF";
    public string Icone { get; set; } = "wallet";
    public decimal SaldoInicial { get; set; }
    public bool Principal { get; set; }
}

public class AtualizarContaRequest
{
    public string? Nome { get; set; }
    public string? Banco { get; set; }
    public string? Cor { get; set; }
    public string? Icone { get; set; }
    public bool? Principal { get; set; }
}

public class ContaResponse
{
    public Guid Id { get; set; }
    public string Nome { get; set; } = string.Empty;
    public string TipoConta { get; set; } = string.Empty;
    public string? Banco { get; set; }
    public string Cor { get; set; } = string.Empty;
    public string Icone { get; set; } = string.Empty;
    public decimal SaldoAtual { get; set; }
    public bool Principal { get; set; }
}

public class TransferenciaRequest
{
    public Guid ContaOrigemId { get; set; }
    public Guid ContaDestinoId { get; set; }
    public decimal Valor { get; set; }
    public string? Descricao { get; set; }
}
