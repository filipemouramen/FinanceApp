namespace FinanceApp.Application.DTOs.CartoesCredito;

public class CriarCartaoCreditoRequest
{
    public Guid? ContaId { get; set; }
    public string Nome { get; set; } = string.Empty;
    public string? Bandeira { get; set; }
    public string? UltimosDigitos { get; set; }
    public decimal Limite { get; set; }
    public int DiaFechamento { get; set; }
    public int DiaVencimento { get; set; }
    public string Cor { get; set; } = "#FF4757";
}

public class CartaoCreditoResponse
{
    public Guid Id { get; set; }
    public string Nome { get; set; } = string.Empty;
    public string? Bandeira { get; set; }
    public string? UltimosDigitos { get; set; }
    public decimal Limite { get; set; }
    public decimal LimiteDisponivel { get; set; }
    public int DiaFechamento { get; set; }
    public int DiaVencimento { get; set; }
    public string Cor { get; set; } = string.Empty;
    public string? NomeConta { get; set; }
}

public class FaturaCartaoResponse
{
    public Guid Id { get; set; }
    public Guid CartaoCreditoId { get; set; }
    public string NomeCartao { get; set; } = string.Empty;
    public int MesReferencia { get; set; }
    public int AnoReferencia { get; set; }
    public DateOnly DataFechamento { get; set; }
    public DateOnly DataVencimento { get; set; }
    public decimal ValorTotal { get; set; }
    public decimal ValorPago { get; set; }
    public string Status { get; set; } = string.Empty;
    public List<TransacaoFaturaResponse> Transacoes { get; set; } = new();
}

public class TransacaoFaturaResponse
{
    public Guid Id { get; set; }
    public string? Descricao { get; set; }
    public string NomeCategoria { get; set; } = string.Empty;
    public decimal Valor { get; set; }
    public DateOnly DataTransacao { get; set; }
    public int? NumeroParcela { get; set; }
    public int? TotalParcelas { get; set; }
}

public class PagarFaturaRequest
{
    public decimal Valor { get; set; }
    public Guid ContaId { get; set; }
}
