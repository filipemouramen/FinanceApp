namespace FinanceApp.Application.DTOs.Metas;

public class CriarMetaRequest
{
    public string Titulo { get; set; } = string.Empty;
    public decimal ValorAlvo { get; set; }
    public DateOnly? DataLimite { get; set; }
    public string? Icone { get; set; }
    public string? Cor { get; set; }
}

public class MetaResponse
{
    public Guid Id { get; set; }
    public string Titulo { get; set; } = string.Empty;
    public decimal ValorAlvo { get; set; }
    public decimal ValorAtual { get; set; }
    public decimal PercentualConcluido => ValorAlvo > 0 ? Math.Round(ValorAtual / ValorAlvo * 100, 1) : 0;
    public DateOnly? DataLimite { get; set; }
    public string? Icone { get; set; }
    public string? Cor { get; set; }
    public bool Concluida { get; set; }
}

public class LancamentoMetaRequest
{
    public decimal Valor { get; set; }
    public string? Observacoes { get; set; }
}
