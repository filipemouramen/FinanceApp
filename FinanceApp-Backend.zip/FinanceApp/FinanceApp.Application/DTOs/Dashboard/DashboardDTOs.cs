namespace FinanceApp.Application.DTOs.Dashboard;

public class DashboardResponse
{
    public decimal TotalReceitas { get; set; }
    public decimal TotalDespesas { get; set; }
    public decimal Saldo { get; set; }
    public List<GastoPorCategoriaResponse> GastosPorCategoria { get; set; } = new();
    public List<BalancoMensalResponse> BalancoMensal { get; set; } = new();
    public List<TransacaoRecenteResponse> TransacoesRecentes { get; set; } = new();
    public List<OrcamentoResumoResponse> OrcamentosAtivos { get; set; } = new();
}

public class GastoPorCategoriaResponse
{
    public int CategoriaId { get; set; }
    public string NomeCategoria { get; set; } = string.Empty;
    public string IconeCategoria { get; set; } = string.Empty;
    public string CorCategoria { get; set; } = string.Empty;
    public decimal ValorTotal { get; set; }
    public decimal Percentual { get; set; }
    public int QuantidadeTransacoes { get; set; }
}

public class BalancoMensalResponse
{
    public int Ano { get; set; }
    public int Mes { get; set; }
    public decimal TotalReceitas { get; set; }
    public decimal TotalDespesas { get; set; }
    public decimal Saldo { get; set; }
}

public class TransacaoRecenteResponse
{
    public Guid Id { get; set; }
    public string? Descricao { get; set; }
    public string NomeCategoria { get; set; } = string.Empty;
    public string IconeCategoria { get; set; } = string.Empty;
    public string CorCategoria { get; set; } = string.Empty;
    public decimal Valor { get; set; }
    public string Tipo { get; set; } = string.Empty;
    public DateOnly DataTransacao { get; set; }
}

public class OrcamentoResumoResponse
{
    public string NomeCategoria { get; set; } = string.Empty;
    public string CorCategoria { get; set; } = string.Empty;
    public decimal ValorLimite { get; set; }
    public decimal TotalGasto { get; set; }
    public decimal PercentualUsado { get; set; }
}
