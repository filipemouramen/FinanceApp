namespace FinanceApp.Application.DTOs.Transacoes;

public class CriarTransacaoRequest
{
    public int CategoriaId { get; set; }
    public Guid? ContaId { get; set; }
    public int? FormaPagamentoId { get; set; }
    public Guid? CartaoCreditoId { get; set; }
    public decimal Valor { get; set; }
    public string Tipo { get; set; } = "DESPESA";
    public string? Descricao { get; set; }
    public DateOnly? DataTransacao { get; set; }
    public string? Observacoes { get; set; }
    // Parcelamento
    public int? TotalParcelas { get; set; }
}

public class AtualizarTransacaoRequest
{
    public int? CategoriaId { get; set; }
    public Guid? ContaId { get; set; }
    public int? FormaPagamentoId { get; set; }
    public decimal? Valor { get; set; }
    public string? Descricao { get; set; }
    public DateOnly? DataTransacao { get; set; }
    public string? Observacoes { get; set; }
}

public class TransacaoResponse
{
    public Guid Id { get; set; }
    public int CategoriaId { get; set; }
    public string NomeCategoria { get; set; } = string.Empty;
    public string IconeCategoria { get; set; } = string.Empty;
    public string CorCategoria { get; set; } = string.Empty;
    public Guid? ContaId { get; set; }
    public string? NomeConta { get; set; }
    public int? FormaPagamentoId { get; set; }
    public string? NomeFormaPagamento { get; set; }
    public Guid? CartaoCreditoId { get; set; }
    public string? NomeCartaoCredito { get; set; }
    public decimal Valor { get; set; }
    public string Tipo { get; set; } = string.Empty;
    public string? Descricao { get; set; }
    public DateOnly DataTransacao { get; set; }
    public string Origem { get; set; } = string.Empty;
    public string? Observacoes { get; set; }
    public int? NumeroParcela { get; set; }
    public int? TotalParcelas { get; set; }
    public DateTime CriadoEm { get; set; }
}

public class FiltroTransacaoRequest
{
    public DateOnly? DataInicio { get; set; }
    public DateOnly? DataFim { get; set; }
    public string? Tipo { get; set; }
    public int? CategoriaId { get; set; }
    public Guid? ContaId { get; set; }
    public string? Origem { get; set; }
    public int Pagina { get; set; } = 1;
    public int ItensPorPagina { get; set; } = 20;
}

public class ListaPaginada<T>
{
    public List<T> Itens { get; set; } = new();
    public int TotalItens { get; set; }
    public int Pagina { get; set; }
    public int ItensPorPagina { get; set; }
    public int TotalPaginas => (int)Math.Ceiling(TotalItens / (double)ItensPorPagina);
}
