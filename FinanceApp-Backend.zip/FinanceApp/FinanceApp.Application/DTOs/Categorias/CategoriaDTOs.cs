namespace FinanceApp.Application.DTOs.Categorias;

public class CategoriaResponse
{
    public int Id { get; set; }
    public string Nome { get; set; } = string.Empty;
    public string Icone { get; set; } = string.Empty;
    public string Cor { get; set; } = string.Empty;
    public string Tipo { get; set; } = string.Empty;
    public bool Padrao { get; set; }
}

public class CriarCategoriaRequest
{
    public string Nome { get; set; } = string.Empty;
    public string Icone { get; set; } = string.Empty;
    public string Cor { get; set; } = "#6C63FF";
    public string Tipo { get; set; } = "DESPESA";
}
