namespace FinanceApp.Application.DTOs.Orcamentos;

public class CriarOrcamentoRequest
{
    public int CategoriaId { get; set; }
    public decimal ValorLimite { get; set; }
    public int Mes { get; set; }
    public int Ano { get; set; }
    public int PercentualAlerta { get; set; } = 80;
}

public class OrcamentoResponse
{
    public Guid Id { get; set; }
    public int CategoriaId { get; set; }
    public string NomeCategoria { get; set; } = string.Empty;
    public string IconeCategoria { get; set; } = string.Empty;
    public string CorCategoria { get; set; } = string.Empty;
    public decimal ValorLimite { get; set; }
    public decimal TotalGasto { get; set; }
    public decimal PercentualUsado { get; set; }
    public int PercentualAlerta { get; set; }
    public int Mes { get; set; }
    public int Ano { get; set; }
}
