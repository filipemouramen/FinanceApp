using FinanceApp.Application.DTOs.Categorias;
using FinanceApp.Application.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace FinanceApp.API.Controllers;

[Route("api/[controller]")]
[ApiController]
[Authorize]
public class CategoriasController : BaseController
{
    private readonly ICategoriaService _categoriaService;

    public CategoriasController(ICategoriaService categoriaService)
    {
        _categoriaService = categoriaService;
    }

    /// <summary>
    /// Listar categorias (padrão + personalizadas do usuário)
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> Listar([FromQuery] string? tipo = null)
    {
        var resultado = await _categoriaService.ListarAsync(UsuarioIdAtual, tipo);
        return Ok(resultado);
    }

    /// <summary>
    /// Criar categoria personalizada
    /// </summary>
    [HttpPost]
    public async Task<IActionResult> Criar([FromBody] CriarCategoriaRequest request)
    {
        var resultado = await _categoriaService.CriarAsync(UsuarioIdAtual, request);
        if (!resultado.Sucesso)
            return BadRequest(resultado);

        return Ok(resultado);
    }

    /// <summary>
    /// Excluir categoria personalizada (não permite excluir padrão)
    /// </summary>
    [HttpDelete("{id:int}")]
    public async Task<IActionResult> Excluir(int id)
    {
        var resultado = await _categoriaService.ExcluirAsync(UsuarioIdAtual, id);
        if (!resultado.Sucesso)
            return BadRequest(resultado);

        return Ok(resultado);
    }
}
