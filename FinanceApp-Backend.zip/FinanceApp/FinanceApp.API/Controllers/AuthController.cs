using FinanceApp.Application.DTOs.Auth;
using FinanceApp.Application.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace FinanceApp.API.Controllers;

[Route("api/[controller]")]
[ApiController]
public class AuthController : BaseController
{
    private readonly IAuthService _authService;

    public AuthController(IAuthService authService)
    {
        _authService = authService;
    }

    /// <summary>
    /// Registrar novo usuário
    /// </summary>
    [HttpPost("registrar")]
    [AllowAnonymous]
    public async Task<IActionResult> Registrar([FromBody] RegistroRequest request)
    {
        var resultado = await _authService.RegistrarAsync(request);
        if (!resultado.Sucesso)
            return BadRequest(resultado);

        return Ok(resultado);
    }

    /// <summary>
    /// Login do usuário
    /// </summary>
    [HttpPost("login")]
    [AllowAnonymous]
    public async Task<IActionResult> Login([FromBody] LoginRequest request)
    {
        var resultado = await _authService.LoginAsync(request);
        if (!resultado.Sucesso)
            return Unauthorized(resultado);

        return Ok(resultado);
    }

    /// <summary>
    /// Renovar token JWT
    /// </summary>
    [HttpPost("refresh-token")]
    [AllowAnonymous]
    public async Task<IActionResult> RefreshToken([FromBody] RefreshTokenRequest request)
    {
        var resultado = await _authService.RefreshTokenAsync(request);
        if (!resultado.Sucesso)
            return Unauthorized(resultado);

        return Ok(resultado);
    }

    /// <summary>
    /// Alterar senha do usuário logado
    /// </summary>
    [HttpPost("alterar-senha")]
    [Authorize]
    public async Task<IActionResult> AlterarSenha([FromBody] AlterarSenhaRequest request)
    {
        var resultado = await _authService.AlterarSenhaAsync(UsuarioIdAtual, request);
        if (!resultado.Sucesso)
            return BadRequest(resultado);

        return Ok(resultado);
    }

    /// <summary>
    /// Solicitar código para resetar senha
    /// </summary>
    [HttpPost("solicitar-reset-senha")]
    [AllowAnonymous]
    public async Task<IActionResult> SolicitarResetSenha([FromBody] SolicitarResetSenhaRequest request)
    {
        var resultado = await _authService.SolicitarResetSenhaAsync(request);
        return Ok(resultado);
    }

    /// <summary>
    /// Resetar senha com código recebido
    /// </summary>
    [HttpPost("resetar-senha")]
    [AllowAnonymous]
    public async Task<IActionResult> ResetarSenha([FromBody] ResetarSenhaRequest request)
    {
        var resultado = await _authService.ResetarSenhaAsync(request);
        if (!resultado.Sucesso)
            return BadRequest(resultado);

        return Ok(resultado);
    }

    /// <summary>
    /// Logout - revogar todos os refresh tokens
    /// </summary>
    [HttpPost("logout")]
    [Authorize]
    public async Task<IActionResult> Logout()
    {
        var resultado = await _authService.RevogarTokenAsync(UsuarioIdAtual);
        return Ok(resultado);
    }
}
