using FinanceApp.Application.DTOs.Contas;
using FinanceApp.Application.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace FinanceApp.API.Controllers;

[Route("api/[controller]")]
[ApiController]
[Authorize]
public class ContasController : BaseController
{
    private readonly IContaService _contaService;

    public ContasController(IContaService contaService)
    {
        _contaService = contaService;
    }

    [HttpGet]
    public async Task<IActionResult> Listar()
    {
        var resultado = await _contaService.ListarAsync(UsuarioIdAtual);
        return Ok(resultado);
    }

    [HttpPost]
    public async Task<IActionResult> Criar([FromBody] CriarContaRequest request)
    {
        var resultado = await _contaService.CriarAsync(UsuarioIdAtual, request);
        if (!resultado.Sucesso) return BadRequest(resultado);
        return Ok(resultado);
    }

    [HttpPut("{id:guid}")]
    public async Task<IActionResult> Atualizar(Guid id, [FromBody] AtualizarContaRequest request)
    {
        var resultado = await _contaService.AtualizarAsync(UsuarioIdAtual, id, request);
        if (!resultado.Sucesso) return BadRequest(resultado);
        return Ok(resultado);
    }

    [HttpDelete("{id:guid}")]
    public async Task<IActionResult> Excluir(Guid id)
    {
        var resultado = await _contaService.ExcluirAsync(UsuarioIdAtual, id);
        if (!resultado.Sucesso) return BadRequest(resultado);
        return Ok(resultado);
    }

    /// <summary>
    /// Transferir valor entre contas
    /// </summary>
    [HttpPost("transferir")]
    public async Task<IActionResult> Transferir([FromBody] TransferenciaRequest request)
    {
        var resultado = await _contaService.TransferirAsync(UsuarioIdAtual, request);
        if (!resultado.Sucesso) return BadRequest(resultado);
        return Ok(resultado);
    }
}
