using FinanceApp.Application.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace FinanceApp.API.Controllers;

[Route("api/[controller]")]
[ApiController]
[Authorize]
public class DashboardController : BaseController
{
    private readonly IDashboardService _dashboardService;

    public DashboardController(IDashboardService dashboardService)
    {
        _dashboardService = dashboardService;
    }

    /// <summary>
    /// Obter dados do dashboard (resumo mensal, gráficos, etc.)
    /// </summary>
    [HttpGet("{mes:int}/{ano:int}")]
    public async Task<IActionResult> Obter(int mes, int ano)
    {
        if (mes < 1 || mes > 12)
            return BadRequest(Resultado<object>.Falha("Mês inválido."));

        var resultado = await _dashboardService.ObterAsync(UsuarioIdAtual, mes, ano);
        return Ok(resultado);
    }

    /// <summary>
    /// Dashboard do mês atual
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> ObterAtual()
    {
        var hoje = DateTime.UtcNow;
        var resultado = await _dashboardService.ObterAsync(UsuarioIdAtual, hoje.Month, hoje.Year);
        return Ok(resultado);
    }
}
