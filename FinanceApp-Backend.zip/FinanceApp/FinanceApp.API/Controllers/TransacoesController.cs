using FinanceApp.Application.DTOs.Transacoes;
using FinanceApp.Application.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace FinanceApp.API.Controllers;

[Route("api/[controller]")]
[ApiController]
[Authorize]
public class TransacoesController : BaseController
{
    private readonly ITransacaoService _transacaoService;

    public TransacoesController(ITransacaoService transacaoService)
    {
        _transacaoService = transacaoService;
    }

    /// <summary>
    /// Listar transações com filtros e paginação
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> Listar([FromQuery] FiltroTransacaoRequest filtro)
    {
        var resultado = await _transacaoService.ListarAsync(UsuarioIdAtual, filtro);
        return Ok(resultado);
    }

    /// <summary>
    /// Obter transação por ID
    /// </summary>
    [HttpGet("{id:guid}")]
    public async Task<IActionResult> ObterPorId(Guid id)
    {
        var resultado = await _transacaoService.ObterPorIdAsync(UsuarioIdAtual, id);
        if (!resultado.Sucesso)
            return NotFound(resultado);

        return Ok(resultado);
    }

    /// <summary>
    /// Criar nova transação (gasto ou receita)
    /// </summary>
    [HttpPost]
    public async Task<IActionResult> Criar([FromBody] CriarTransacaoRequest request)
    {
        var resultado = await _transacaoService.CriarAsync(UsuarioIdAtual, request);
        if (!resultado.Sucesso)
            return BadRequest(resultado);

        return CreatedAtAction(nameof(ObterPorId), new { id = resultado.Dados!.Id }, resultado);
    }

    /// <summary>
    /// Atualizar transação existente
    /// </summary>
    [HttpPut("{id:guid}")]
    public async Task<IActionResult> Atualizar(Guid id, [FromBody] AtualizarTransacaoRequest request)
    {
        var resultado = await _transacaoService.AtualizarAsync(UsuarioIdAtual, id, request);
        if (!resultado.Sucesso)
            return BadRequest(resultado);

        return Ok(resultado);
    }

    /// <summary>
    /// Excluir transação
    /// </summary>
    [HttpDelete("{id:guid}")]
    public async Task<IActionResult> Excluir(Guid id)
    {
        var resultado = await _transacaoService.ExcluirAsync(UsuarioIdAtual, id);
        if (!resultado.Sucesso)
            return NotFound(resultado);

        return Ok(resultado);
    }
}
