# Finance App - Backend API (ASP.NET Core 8)

## Estrutura do Projeto

```
FinanceApp/
├── FinanceApp.sln                          ← Abrir este arquivo no Visual Studio
├── FinanceApp.API/                         ← Projeto principal (Controllers, Program.cs)
│   ├── Controllers/
│   │   ├── BaseController.cs
│   │   ├── AuthController.cs
│   │   ├── TransacoesController.cs
│   │   ├── CategoriasController.cs
│   │   ├── ContasController.cs
│   │   └── DashboardController.cs
│   ├── Program.cs
│   ├── appsettings.json                    ← CONFIGURAR CONNECTION STRING AQUI
│   └── appsettings.Development.json
├── FinanceApp.Domain/                      ← Entidades e Enums
│   ├── Entities/ (18 entidades)
│   └── Enums/
├── FinanceApp.Application/                 ← Services, DTOs, Interfaces
│   ├── DTOs/
│   ├── Interfaces/
│   └── Services/
└── FinanceApp.Infrastructure/              ← DbContext, EF Core
    └── Data/
        └── FinanceDbContext.cs
```

## Como Configurar

### 1. Abrir no Visual Studio
- Abra o arquivo `FinanceApp.sln` no Visual Studio 2022

### 2. Configurar a Connection String
- Abra `FinanceApp.API/appsettings.json`
- Altere a `DefaultConnection` com os dados do seu SQL Server:

```json
"ConnectionStrings": {
    "DefaultConnection": "Server=SEU_SERVIDOR;Database=FinanceApp;Trusted_Connection=true;TrustServerCertificate=true;MultipleActiveResultSets=true"
}
```

Exemplos:
- SQL Server local: `Server=localhost;Database=FinanceApp;Trusted_Connection=true;TrustServerCertificate=true`
- SQL Server Express: `Server=localhost\\SQLEXPRESS;Database=FinanceApp;Trusted_Connection=true;TrustServerCertificate=true`
- Com usuário/senha: `Server=localhost;Database=FinanceApp;User Id=sa;Password=SuaSenha;TrustServerCertificate=true`

### 3. Alterar a chave JWT (IMPORTANTE para produção)
- No `appsettings.json`, troque o valor de `Jwt:Secret` por uma chave segura sua

### 4. Restaurar pacotes NuGet
- No Visual Studio: clique com botão direito na Solution → "Restore NuGet Packages"
- Ou via terminal: `dotnet restore`

### 5. Criar o banco de dados

**Opção A - Via Entity Framework Migrations (RECOMENDADO):**
```bash
# No terminal, na pasta raiz do projeto:
dotnet ef migrations add Inicial --project FinanceApp.Infrastructure --startup-project FinanceApp.API
dotnet ef database update --project FinanceApp.Infrastructure --startup-project FinanceApp.API
```

**Opção B - Via Script SQL:**
- Execute o arquivo `FinanceApp_BancoDeDados_v2.sql` diretamente no SQL Server Management Studio

### 6. Rodar o projeto
- No Visual Studio: F5 ou Ctrl+F5
- Via terminal: `dotnet run --project FinanceApp.API`
- Acesse o Swagger em: `https://localhost:PORTA/swagger`

## Endpoints da API

### Auth (público)
- `POST /api/auth/registrar` - Criar conta
- `POST /api/auth/login` - Login (retorna JWT)
- `POST /api/auth/refresh-token` - Renovar token
- `POST /api/auth/solicitar-reset-senha` - Pedir código de reset
- `POST /api/auth/resetar-senha` - Resetar com código

### Auth (autenticado)
- `POST /api/auth/alterar-senha` - Alterar senha
- `POST /api/auth/logout` - Revogar tokens

### Transações (autenticado)
- `GET /api/transacoes` - Listar com filtros e paginação
- `GET /api/transacoes/{id}` - Obter por ID
- `POST /api/transacoes` - Criar (suporta parcelamento)
- `PUT /api/transacoes/{id}` - Atualizar
- `DELETE /api/transacoes/{id}` - Excluir

### Categorias (autenticado)
- `GET /api/categorias?tipo=DESPESA` - Listar
- `POST /api/categorias` - Criar personalizada
- `DELETE /api/categorias/{id}` - Excluir personalizada

### Contas (autenticado)
- `GET /api/contas` - Listar
- `POST /api/contas` - Criar
- `PUT /api/contas/{id}` - Atualizar
- `DELETE /api/contas/{id}` - Excluir
- `POST /api/contas/transferir` - Transferir entre contas

### Dashboard (autenticado)
- `GET /api/dashboard` - Dashboard do mês atual
- `GET /api/dashboard/{mes}/{ano}` - Dashboard de mês específico

## Tecnologias
- .NET 8 (LTS)
- ASP.NET Core Web API
- ASP.NET Identity + JWT Bearer
- Entity Framework Core 8
- SQL Server
- Swagger/OpenAPI

## Próximos Passos
1. Implementar services restantes (CategoriaService, ContaService, etc.)
2. Implementar integração com WhatsApp (Meta Cloud API)
3. Conectar com o frontend React Native (Expo Go)
