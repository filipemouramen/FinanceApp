using FinanceApp.Domain.Entities;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace FinanceApp.Infrastructure.Data;

public class FinanceDbContext : IdentityDbContext<Usuario, IdentityRole<Guid>, Guid>
{
    public FinanceDbContext(DbContextOptions<FinanceDbContext> options) : base(options) { }

    // Tabelas
    public DbSet<TokenAtualizacao> TokensAtualizacao => Set<TokenAtualizacao>();
    public DbSet<CodigoVerificacao> CodigosVerificacao => Set<CodigoVerificacao>();
    public DbSet<Categoria> Categorias => Set<Categoria>();
    public DbSet<FormaPagamento> FormasPagamento => Set<FormaPagamento>();
    public DbSet<Conta> Contas => Set<Conta>();
    public DbSet<CartaoCredito> CartoesCredito => Set<CartaoCredito>();
    public DbSet<FaturaCartao> FaturasCartao => Set<FaturaCartao>();
    public DbSet<Transacao> Transacoes => Set<Transacao>();
    public DbSet<Parcelamento> Parcelamentos => Set<Parcelamento>();
    public DbSet<RegraRecorrencia> RegrasRecorrencia => Set<RegraRecorrencia>();
    public DbSet<Orcamento> Orcamentos => Set<Orcamento>();
    public DbSet<MetaEconomia> MetasEconomia => Set<MetaEconomia>();
    public DbSet<LancamentoMeta> LancamentosMeta => Set<LancamentoMeta>();
    public DbSet<TransferenciaConta> TransferenciasContas => Set<TransferenciaConta>();
    public DbSet<Anexo> Anexos => Set<Anexo>();
    public DbSet<MensagemWhatsApp> MensagensWhatsApp => Set<MensagemWhatsApp>();
    public DbSet<ApelidoCategoria> ApelidosCategorias => Set<ApelidoCategoria>();
    public DbSet<Notificacao> Notificacoes => Set<Notificacao>();
    public DbSet<ConfiguracaoUsuario> ConfiguracoesUsuario => Set<ConfiguracaoUsuario>();
    public DbSet<LogAuditoria> LogsAuditoria => Set<LogAuditoria>();

    protected override void OnModelCreating(ModelBuilder builder)
    {
        base.OnModelCreating(builder); // Identity tables

        // ===== USUARIO =====
        builder.Entity<Usuario>(e =>
        {
            e.ToTable("Usuarios");
            e.Property(u => u.NomeCompleto).HasMaxLength(150).IsRequired();
            e.Property(u => u.TelefoneWhatsApp).HasMaxLength(20);
            e.Property(u => u.FotoUrl).HasMaxLength(500);
            e.HasIndex(u => u.TelefoneWhatsApp).IsUnique().HasFilter("[TelefoneWhatsApp] IS NOT NULL");
        });

        // ===== TOKEN ATUALIZACAO =====
        builder.Entity<TokenAtualizacao>(e =>
        {
            e.ToTable("TokensAtualizacao");
            e.HasKey(t => t.Id);
            e.Property(t => t.Token).HasMaxLength(512).IsRequired();
            e.Property(t => t.SubstituidoPor).HasMaxLength(512);
            e.HasIndex(t => t.Token);
            e.HasIndex(t => t.UsuarioId);
            e.HasOne(t => t.Usuario)
                .WithMany(u => u.TokensAtualizacao)
                .HasForeignKey(t => t.UsuarioId)
                .OnDelete(DeleteBehavior.Cascade);
        });

        // ===== CODIGO VERIFICACAO =====
        builder.Entity<CodigoVerificacao>(e =>
        {
            e.ToTable("CodigosVerificacao");
            e.HasKey(c => c.Id);
            e.Property(c => c.Codigo).HasMaxLength(10).IsRequired();
            e.Property(c => c.Finalidade).HasMaxLength(30)
                .HasConversion<string>().IsRequired();
            e.HasOne(c => c.Usuario)
                .WithMany()
                .HasForeignKey(c => c.UsuarioId)
                .OnDelete(DeleteBehavior.Cascade);
        });

        // ===== CATEGORIA =====
        builder.Entity<Categoria>(e =>
        {
            e.ToTable("Categorias");
            e.HasKey(c => c.Id);
            e.Property(c => c.Nome).HasMaxLength(80).IsRequired();
            e.Property(c => c.Icone).HasMaxLength(50).IsRequired();
            e.Property(c => c.Cor).HasMaxLength(7);
            e.Property(c => c.Tipo).HasMaxLength(10)
                .HasConversion<string>().IsRequired();
            e.HasOne(c => c.Usuario)
                .WithMany()
                .HasForeignKey(c => c.UsuarioId)
                .OnDelete(DeleteBehavior.SetNull);
        });

        // ===== FORMA PAGAMENTO =====
        builder.Entity<FormaPagamento>(e =>
        {
            e.ToTable("FormasPagamento");
            e.HasKey(f => f.Id);
            e.Property(f => f.Nome).HasMaxLength(50).IsRequired();
            e.Property(f => f.Icone).HasMaxLength(50).IsRequired();
        });

        // ===== CONTA =====
        builder.Entity<Conta>(e =>
        {
            e.ToTable("Contas");
            e.HasKey(c => c.Id);
            e.Property(c => c.Nome).HasMaxLength(100).IsRequired();
            e.Property(c => c.TipoConta).HasMaxLength(20)
                .HasConversion<string>().IsRequired();
            e.Property(c => c.Banco).HasMaxLength(80);
            e.Property(c => c.Cor).HasMaxLength(7);
            e.Property(c => c.Icone).HasMaxLength(50);
            e.Property(c => c.SaldoInicial).HasColumnType("decimal(18,2)");
            e.Property(c => c.SaldoAtual).HasColumnType("decimal(18,2)");
            e.HasIndex(c => c.UsuarioId);
            e.HasOne(c => c.Usuario)
                .WithMany(u => u.Contas)
                .HasForeignKey(c => c.UsuarioId)
                .OnDelete(DeleteBehavior.Cascade);
        });

        // ===== CARTAO DE CREDITO =====
        builder.Entity<CartaoCredito>(e =>
        {
            e.ToTable("CartoesCredito");
            e.HasKey(c => c.Id);
            e.Property(c => c.Nome).HasMaxLength(100).IsRequired();
            e.Property(c => c.Bandeira).HasMaxLength(30);
            e.Property(c => c.UltimosDigitos).HasMaxLength(4);
            e.Property(c => c.Limite).HasColumnType("decimal(18,2)");
            e.Property(c => c.LimiteDisponivel).HasColumnType("decimal(18,2)");
            e.Property(c => c.Cor).HasMaxLength(7);
            e.HasIndex(c => c.UsuarioId);
            e.HasOne(c => c.Usuario)
                .WithMany(u => u.CartoesCredito)
                .HasForeignKey(c => c.UsuarioId)
                .OnDelete(DeleteBehavior.Cascade);
            e.HasOne(c => c.Conta)
                .WithMany(ct => ct.CartoesCredito)
                .HasForeignKey(c => c.ContaId)
                .OnDelete(DeleteBehavior.SetNull);
        });

        // ===== FATURA CARTAO =====
        builder.Entity<FaturaCartao>(e =>
        {
            e.ToTable("FaturasCartao");
            e.HasKey(f => f.Id);
            e.Property(f => f.ValorTotal).HasColumnType("decimal(18,2)");
            e.Property(f => f.ValorPago).HasColumnType("decimal(18,2)");
            e.Property(f => f.Status).HasMaxLength(15)
                .HasConversion<string>().IsRequired();
            e.HasIndex(f => f.UsuarioId);
            e.HasIndex(f => new { f.CartaoCreditoId, f.MesReferencia, f.AnoReferencia }).IsUnique();
            e.HasOne(f => f.CartaoCredito)
                .WithMany(c => c.Faturas)
                .HasForeignKey(f => f.CartaoCreditoId)
                .OnDelete(DeleteBehavior.Cascade);
            e.HasOne(f => f.Usuario)
                .WithMany()
                .HasForeignKey(f => f.UsuarioId)
                .OnDelete(DeleteBehavior.NoAction);
        });

        // ===== TRANSACAO =====
        builder.Entity<Transacao>(e =>
        {
            e.ToTable("Transacoes");
            e.HasKey(t => t.Id);
            e.Property(t => t.Valor).HasColumnType("decimal(18,2)");
            e.Property(t => t.Tipo).HasMaxLength(10)
                .HasConversion<string>().IsRequired();
            e.Property(t => t.Descricao).HasMaxLength(300);
            e.Property(t => t.Origem).HasMaxLength(10)
                .HasConversion<string>().IsRequired();
            e.Property(t => t.Observacoes).HasMaxLength(500);

            e.HasIndex(t => t.UsuarioId);
            e.HasIndex(t => new { t.UsuarioId, t.DataTransacao });
            e.HasIndex(t => new { t.UsuarioId, t.CategoriaId });
            e.HasIndex(t => new { t.UsuarioId, t.ContaId });
            e.HasIndex(t => t.FaturaCartaoId);

            e.HasOne(t => t.Usuario)
                .WithMany(u => u.Transacoes)
                .HasForeignKey(t => t.UsuarioId)
                .OnDelete(DeleteBehavior.Cascade);
            e.HasOne(t => t.Categoria)
                .WithMany(c => c.Transacoes)
                .HasForeignKey(t => t.CategoriaId)
                .OnDelete(DeleteBehavior.NoAction);
            e.HasOne(t => t.Conta)
                .WithMany(c => c.Transacoes)
                .HasForeignKey(t => t.ContaId)
                .OnDelete(DeleteBehavior.NoAction);
            e.HasOne(t => t.FormaPagamento)
                .WithMany(f => f.Transacoes)
                .HasForeignKey(t => t.FormaPagamentoId)
                .OnDelete(DeleteBehavior.NoAction);
            e.HasOne(t => t.CartaoCredito)
                .WithMany(c => c.Transacoes)
                .HasForeignKey(t => t.CartaoCreditoId)
                .OnDelete(DeleteBehavior.NoAction);
            e.HasOne(t => t.FaturaCartao)
                .WithMany(f => f.Transacoes)
                .HasForeignKey(t => t.FaturaCartaoId)
                .OnDelete(DeleteBehavior.NoAction);
            e.HasOne(t => t.RegraRecorrencia)
                .WithMany(r => r.Transacoes)
                .HasForeignKey(t => t.RegraRecorrenciaId)
                .OnDelete(DeleteBehavior.NoAction);
            e.HasOne(t => t.Parcelamento)
                .WithMany(p => p.Transacoes)
                .HasForeignKey(t => t.ParcelamentoId)
                .OnDelete(DeleteBehavior.NoAction);
        });

        // ===== PARCELAMENTO =====
        builder.Entity<Parcelamento>(e =>
        {
            e.ToTable("Parcelamentos");
            e.HasKey(p => p.Id);
            e.Property(p => p.Descricao).HasMaxLength(300).IsRequired();
            e.Property(p => p.ValorTotal).HasColumnType("decimal(18,2)");
            e.Property(p => p.ValorParcela).HasColumnType("decimal(18,2)");
            e.HasIndex(p => p.UsuarioId);
            e.HasOne(p => p.Usuario)
                .WithMany()
                .HasForeignKey(p => p.UsuarioId)
                .OnDelete(DeleteBehavior.Cascade);
            e.HasOne(p => p.CartaoCredito)
                .WithMany(c => c.Parcelamentos)
                .HasForeignKey(p => p.CartaoCreditoId)
                .OnDelete(DeleteBehavior.NoAction);
            e.HasOne(p => p.Categoria)
                .WithMany()
                .HasForeignKey(p => p.CategoriaId)
                .OnDelete(DeleteBehavior.NoAction);
        });

        // ===== REGRA RECORRENCIA =====
        builder.Entity<RegraRecorrencia>(e =>
        {
            e.ToTable("RegrasRecorrencia");
            e.HasKey(r => r.Id);
            e.Property(r => r.Descricao).HasMaxLength(300).IsRequired();
            e.Property(r => r.Valor).HasColumnType("decimal(18,2)");
            e.Property(r => r.Tipo).HasMaxLength(10)
                .HasConversion<string>().IsRequired();
            e.Property(r => r.Frequencia).HasMaxLength(15)
                .HasConversion<string>().IsRequired();
            e.HasOne(r => r.Usuario)
                .WithMany(u => u.RegrasRecorrencia)
                .HasForeignKey(r => r.UsuarioId)
                .OnDelete(DeleteBehavior.Cascade);
            e.HasOne(r => r.Categoria)
                .WithMany()
                .HasForeignKey(r => r.CategoriaId)
                .OnDelete(DeleteBehavior.NoAction);
            e.HasOne(r => r.Conta)
                .WithMany()
                .HasForeignKey(r => r.ContaId)
                .OnDelete(DeleteBehavior.NoAction);
            e.HasOne(r => r.FormaPagamento)
                .WithMany()
                .HasForeignKey(r => r.FormaPagamentoId)
                .OnDelete(DeleteBehavior.NoAction);
        });

        // ===== ORCAMENTO =====
        builder.Entity<Orcamento>(e =>
        {
            e.ToTable("Orcamentos");
            e.HasKey(o => o.Id);
            e.Property(o => o.ValorLimite).HasColumnType("decimal(18,2)");
            e.HasIndex(o => new { o.UsuarioId, o.CategoriaId, o.Mes, o.Ano }).IsUnique();
            e.HasOne(o => o.Usuario)
                .WithMany(u => u.Orcamentos)
                .HasForeignKey(o => o.UsuarioId)
                .OnDelete(DeleteBehavior.Cascade);
            e.HasOne(o => o.Categoria)
                .WithMany()
                .HasForeignKey(o => o.CategoriaId)
                .OnDelete(DeleteBehavior.NoAction);
        });

        // ===== META ECONOMIA =====
        builder.Entity<MetaEconomia>(e =>
        {
            e.ToTable("MetasEconomia");
            e.HasKey(m => m.Id);
            e.Property(m => m.Titulo).HasMaxLength(150).IsRequired();
            e.Property(m => m.ValorAlvo).HasColumnType("decimal(18,2)");
            e.Property(m => m.ValorAtual).HasColumnType("decimal(18,2)");
            e.Property(m => m.Icone).HasMaxLength(50);
            e.Property(m => m.Cor).HasMaxLength(7);
            e.HasOne(m => m.Usuario)
                .WithMany(u => u.MetasEconomia)
                .HasForeignKey(m => m.UsuarioId)
                .OnDelete(DeleteBehavior.Cascade);
        });

        // ===== LANCAMENTO META =====
        builder.Entity<LancamentoMeta>(e =>
        {
            e.ToTable("LancamentosMeta");
            e.HasKey(l => l.Id);
            e.Property(l => l.Valor).HasColumnType("decimal(18,2)");
            e.Property(l => l.Observacoes).HasMaxLength(300);
            e.HasOne(l => l.MetaEconomia)
                .WithMany(m => m.Lancamentos)
                .HasForeignKey(l => l.MetaEconomiaId)
                .OnDelete(DeleteBehavior.Cascade);
        });

        // ===== TRANSFERENCIA CONTA =====
        builder.Entity<TransferenciaConta>(e =>
        {
            e.ToTable("TransferenciasContas");
            e.HasKey(t => t.Id);
            e.Property(t => t.Valor).HasColumnType("decimal(18,2)");
            e.Property(t => t.Descricao).HasMaxLength(300);
            e.HasOne(t => t.Usuario)
                .WithMany()
                .HasForeignKey(t => t.UsuarioId)
                .OnDelete(DeleteBehavior.Cascade);
            e.HasOne(t => t.ContaOrigem)
                .WithMany()
                .HasForeignKey(t => t.ContaOrigemId)
                .OnDelete(DeleteBehavior.NoAction);
            e.HasOne(t => t.ContaDestino)
                .WithMany()
                .HasForeignKey(t => t.ContaDestinoId)
                .OnDelete(DeleteBehavior.NoAction);
        });

        // ===== ANEXO =====
        builder.Entity<Anexo>(e =>
        {
            e.ToTable("Anexos");
            e.HasKey(a => a.Id);
            e.Property(a => a.NomeArquivo).HasMaxLength(255).IsRequired();
            e.Property(a => a.UrlArquivo).HasMaxLength(500).IsRequired();
            e.Property(a => a.TipoArquivo).HasMaxLength(20).IsRequired();
            e.HasIndex(a => a.TransacaoId);
            e.HasOne(a => a.Transacao)
                .WithMany(t => t.Anexos)
                .HasForeignKey(a => a.TransacaoId)
                .OnDelete(DeleteBehavior.Cascade);
            e.HasOne(a => a.Usuario)
                .WithMany()
                .HasForeignKey(a => a.UsuarioId)
                .OnDelete(DeleteBehavior.NoAction);
        });

        // ===== MENSAGEM WHATSAPP =====
        builder.Entity<MensagemWhatsApp>(e =>
        {
            e.ToTable("MensagensWhatsApp");
            e.HasKey(m => m.Id);
            e.Property(m => m.NumeroTelefone).HasMaxLength(20).IsRequired();
            e.Property(m => m.MensagemOriginal).HasMaxLength(1000).IsRequired();
            e.Property(m => m.CategoriaIdentificada).HasMaxLength(80);
            e.Property(m => m.ValorIdentificado).HasColumnType("decimal(18,2)");
            e.Property(m => m.MensagemErro).HasMaxLength(500);
            e.HasIndex(m => m.NumeroTelefone);
            e.HasIndex(m => m.UsuarioId);
            e.HasOne(m => m.Usuario)
                .WithMany()
                .HasForeignKey(m => m.UsuarioId)
                .OnDelete(DeleteBehavior.SetNull);
            e.HasOne(m => m.Transacao)
                .WithMany()
                .HasForeignKey(m => m.TransacaoId)
                .OnDelete(DeleteBehavior.SetNull);
        });

        // ===== APELIDO CATEGORIA =====
        builder.Entity<ApelidoCategoria>(e =>
        {
            e.ToTable("ApelidosCategorias");
            e.HasKey(a => a.Id);
            e.Property(a => a.Apelido).HasMaxLength(80).IsRequired();
            e.HasIndex(a => new { a.Apelido, a.UsuarioId }).IsUnique();
            e.HasOne(a => a.Categoria)
                .WithMany(c => c.Apelidos)
                .HasForeignKey(a => a.CategoriaId)
                .OnDelete(DeleteBehavior.Cascade);
            e.HasOne(a => a.Usuario)
                .WithMany()
                .HasForeignKey(a => a.UsuarioId)
                .OnDelete(DeleteBehavior.NoAction);
        });

        // ===== NOTIFICACAO =====
        builder.Entity<Notificacao>(e =>
        {
            e.ToTable("Notificacoes");
            e.HasKey(n => n.Id);
            e.Property(n => n.Titulo).HasMaxLength(150).IsRequired();
            e.Property(n => n.Mensagem).HasMaxLength(500).IsRequired();
            e.Property(n => n.Tipo).HasMaxLength(30).IsRequired();
            e.HasIndex(n => new { n.UsuarioId, n.Lida, n.CriadoEm });
            e.HasOne(n => n.Usuario)
                .WithMany(u => u.Notificacoes)
                .HasForeignKey(n => n.UsuarioId)
                .OnDelete(DeleteBehavior.Cascade);
        });

        // ===== CONFIGURACAO USUARIO =====
        builder.Entity<ConfiguracaoUsuario>(e =>
        {
            e.ToTable("ConfiguracoesUsuario");
            e.HasKey(c => c.UsuarioId);
            e.Property(c => c.Moeda).HasMaxLength(5);
            e.Property(c => c.Idioma).HasMaxLength(5);
            e.HasOne(c => c.Usuario)
                .WithOne(u => u.Configuracoes)
                .HasForeignKey<ConfiguracaoUsuario>(c => c.UsuarioId)
                .OnDelete(DeleteBehavior.Cascade);
        });

        // ===== LOG AUDITORIA =====
        builder.Entity<LogAuditoria>(e =>
        {
            e.ToTable("LogsAuditoria");
            e.HasKey(l => l.Id);
            e.Property(l => l.Id).UseIdentityColumn();
            e.Property(l => l.Acao).HasMaxLength(50).IsRequired();
            e.Property(l => l.TipoEntidade).HasMaxLength(50);
            e.Property(l => l.EntidadeId).HasMaxLength(50);
            e.Property(l => l.EnderecoIP).HasMaxLength(45);
            e.Property(l => l.Navegador).HasMaxLength(500);
            e.HasIndex(l => new { l.UsuarioId, l.CriadoEm });
        });
    }
}
